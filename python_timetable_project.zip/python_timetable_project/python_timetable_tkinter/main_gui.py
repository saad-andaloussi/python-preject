import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import webbrowser
import os
from datetime import datetime
from models import *
from managers import TimetableManager

# --- Style Configuration ---
BG_COLOR = "#f4f4f4"
HEADER_BG = "#333333"
HEADER_FG = "white"
ACCENT_COLOR = "#0078d7"
BTN_FONT = ("Segoe UI", 10)
TITLE_FONT = ("Segoe UI", 20, "bold")
SUBTITLE_FONT = ("Segoe UI", 14)
NORMAL_FONT = ("Segoe UI", 10)

class TimetableApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("UnivTime - Gestion")
        self.geometry("1024x768")
        self.configure(bg=BG_COLOR)
        
        # Apply Theme
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        # Configure Colors and Fonts
        self.style.configure("TFrame", background=BG_COLOR)
        self.style.configure("TLabel", background=BG_COLOR, font=NORMAL_FONT)
        self.style.configure("TButton", font=BTN_FONT, padding=5)
        self.style.configure("Header.TLabel", background=HEADER_BG, foreground=HEADER_FG, font=SUBTITLE_FONT)
        self.style.configure("Card.TFrame", background="white", relief="solid", borderwidth=1)
        self.style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#e1e1e1")
        self.style.configure("Treeview", rowheight=28, font=NORMAL_FONT)

        # Initialize Logic
        self.manager = TimetableManager()
        self.init_demo_data()

        # Container for all frames
        self.container = tk.Frame(self, bg=BG_COLOR)
        self.container.pack(fill="both", expand=True)
        self.container.grid_rowconfigure(0, weight=1)
        self.container.grid_columnconfigure(0, weight=1)
        
        self.frames = {}
        
        # Initialize Frames
        for F in (LoginView, AdminView, TeacherView, StudentView):
            page_name = F.__name__
            frame = F(parent=self.container, controller=self)
            self.frames[page_name] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("LoginView")

    def export_sessions_to_html(self, sessions, title="Emploi du Temps"):
        if not sessions:
            messagebox.showwarning("Export", "Aucune donnée à exporter.")
            return

        file_path = filedialog.asksaveasfilename(
            defaultextension=".html",
            filetypes=[("HTML files", "*.html"), ("All files", "*.*")],
            title="Enregistrer l'emploi du temps"
        )

        if not file_path:
            return

        html_content = f"""
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <title>{title}</title>
            <style>
                body {{ font-family: 'Segoe UI', Arial, sans-serif; padding: 20px; background-color: #fff; color: #000; }}
                h1 {{ text-align: center; color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; font-size: 24px; }}
                .info {{ text-align: center; margin-bottom: 30px; font-style: italic; color: #666; }}
                table {{ width: 100%; border-collapse: collapse; margin: 0 auto; }}
                th, td {{ border: 1px solid #999; padding: 10px; text-align: left; font-size: 14px; }}
                th {{ background-color: #f2f2f2; font-weight: bold; color: #000; }}
                tr:nth-child(even) {{ background-color: #fbfbfb; }}
                .footer {{ margin-top: 40px; text-align: center; font-size: 0.8em; color: #888; border-top: 1px solid #eee; padding-top: 20px; }}
            </style>
        </head>
        <body>
            <h1>{title}</h1>
            <div class="info">Généré le {datetime.now().strftime('%d/%m/%Y à %H:%M')}</div>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Heure</th>
                        <th>Cours</th>
                        <th>Type</th>
                        <th>Groupe</th>
                        <th>Enseignant</th>
                        <th>Salle</th>
                    </tr>
                </thead>
                <tbody>
        """
        
        # Sort sessions by date and time
        sorted_sessions = sorted(sessions, key=lambda s: (s.start_time, s.course.name))

        for s in sorted_sessions:
            room_str = s.room.room_id if s.room else "Non assignée"
            html_content += f"""
                    <tr>
                        <td>{s.start_time.strftime('%Y-%m-%d')}</td>
                        <td>{s.start_time.hour}h - {s.end_time.hour}h</td>
                        <td>{s.course.name}</td>
                        <td>{s.session_type.value}</td>
                        <td>{s.group.name}</td>
                        <td>{s.teacher.name}</td>
                        <td>{room_str}</td>
                    </tr>
            """

        html_content += f"""
                </tbody>
            </table>
            <div class="footer">
                © 2026 UnivTime - Système de Gestion Universitaire
            </div>
        </body>
        </html>
        """
        
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(html_content)
            
            if messagebox.askyesno("Succès", "Export réussi ! Voulez-vous ouvrir le fichier ?"):
                webbrowser.open('file://' + os.path.realpath(file_path))
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'export : {str(e)}")

    def show_frame(self, page_name):
        frame = self.frames[page_name]
        frame.tkraise()
        if hasattr(frame, 'refresh_data'):
            frame.refresh_data()

    def init_demo_data(self):
        # 1. Rooms
        self.manager.add_room(Room("A101", 100, RoomType.AMPHITHEATER, ["Projecteur", "Micro"]))
        self.manager.add_room(Room("C201", 30, RoomType.CLASSROOM, ["Tableau blanc"]))
        self.manager.add_room(Room("C202", 30, RoomType.CLASSROOM, ["Projecteur"]))
        self.manager.add_room(Room("L301", 20, RoomType.LAB, ["PC", "Réseau"]))

        # 2. Teachers
        t1 = Teacher(1, "Mr. Dupont", "dupont@univ.fr", "Informatique")
        t2 = Teacher(2, "Mme. Martin", "martin@univ.fr", "Mathématiques")
        self.manager.add_teacher(t1)
        self.manager.add_teacher(t2)

        # 3. Groups
        g1 = Group("INFO-L1", 25)
        g2 = Group("MATH-L1", 90)
        self.manager.add_group(g1)
        self.manager.add_group(g2)

        # 4. Courses
        self.manager.add_course(Course("ALG01", "Algorithmique"))
        self.manager.add_course(Course("MAT01", "Analyse"))
        self.manager.add_course(Course("WEB01", "Développement Web"))

class LoginView(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg=BG_COLOR)
        self.controller = controller
        
        # Center Card
        card = ttk.Frame(self, style="Card.TFrame", padding=30)
        card.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(card, text="🎓 UnivTime", font=TITLE_FONT, bg="white", fg=ACCENT_COLOR).pack(pady=(0, 10))
        tk.Label(card, text="Gestion d'Emplois du Temps", font=SUBTITLE_FONT, bg="white", fg="#666").pack(pady=(0, 30))

        btn_admin = tk.Button(card, text="⚙️  Espace Administrateur", font=BTN_FONT, bg=ACCENT_COLOR, fg="white", 
                              relief="flat", width=30, pady=8, cursor="hand2",
                              command=lambda: controller.show_frame("AdminView"))
        btn_admin.pack(pady=8)

        btn_teacher = tk.Button(card, text="👨‍🏫  Espace Enseignant", font=BTN_FONT, bg="white", fg="#333", 
                                relief="solid", borderwidth=1, width=30, pady=8, cursor="hand2",
                                command=lambda: controller.show_frame("TeacherView"))
        btn_teacher.pack(pady=8)

        btn_student = tk.Button(card, text="👨‍🎓  Espace Étudiant", font=BTN_FONT, bg="white", fg="#333", 
                                relief="solid", borderwidth=1, width=30, pady=8, cursor="hand2",
                                command=lambda: controller.show_frame("StudentView"))
        btn_student.pack(pady=8)

        tk.Label(card, text="© 2026 UnivTime", font=("Segoe UI", 8), bg="white", fg="#999").pack(pady=(20, 0))

class AdminView(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg=BG_COLOR)
        self.controller = controller
        
        # Header
        header = tk.Frame(self, bg=HEADER_BG, height=50)
        header.pack(fill="x")
        
        btn_back = tk.Button(header, text="⬅ Retour", bg=HEADER_BG, fg="white", font=BTN_FONT, 
                             relief="flat", command=lambda: controller.show_frame("LoginView"))
        btn_back.pack(side="left", padx=15, pady=10)
        
        tk.Label(header, text="ADMINISTRATION", font=SUBTITLE_FONT, bg=HEADER_BG, fg="white").pack(side="left", padx=10)

        # Content
        content = tk.Frame(self, bg=BG_COLOR, padx=20, pady=20)
        content.pack(fill="both", expand=True)

        # Tabs
        notebook = ttk.Notebook(content)
        notebook.pack(fill="both", expand=True)

        # Tab 1: Create Session
        self.tab_create = ttk.Frame(notebook, padding=20)
        notebook.add(self.tab_create, text="   📅 Planifier   ")
        self.setup_create_tab()

        # Tab 2: View Sessions
        self.tab_view = ttk.Frame(notebook, padding=20)
        notebook.add(self.tab_view, text="   👁️ Consulter   ")
        self.setup_view_tab()

        # Tab 3: Statistics
        self.tab_stats = ttk.Frame(notebook, padding=20)
        notebook.add(self.tab_stats, text="   📊 Statistiques   ")
        self.setup_stats_tab()

    def setup_create_tab(self):
        # Split into Left (Form) and Right (Instructions/Logs)
        left_panel = ttk.LabelFrame(self.tab_create, text="Nouvelle Session", padding=20)
        left_panel.pack(side="left", fill="y", padx=(0, 20), anchor="n")

        # Form Fields using Grid
        grid_opts = {'padx': 5, 'pady': 10, 'sticky': 'w'}
        
        ttk.Label(left_panel, text="Cours:").grid(row=0, column=0, **grid_opts)
        self.course_var = tk.StringVar()
        self.course_combo = ttk.Combobox(left_panel, textvariable=self.course_var, state="readonly", width=25)
        self.course_combo.grid(row=0, column=1, **grid_opts)

        ttk.Label(left_panel, text="Type:").grid(row=1, column=0, **grid_opts)
        self.type_var = tk.StringVar()
        self.type_combo = ttk.Combobox(left_panel, textvariable=self.type_var, state="readonly", width=25)
        self.type_combo['values'] = [t.value for t in SessionType]
        self.type_combo.grid(row=1, column=1, **grid_opts)

        ttk.Label(left_panel, text="Groupe:").grid(row=2, column=0, **grid_opts)
        self.group_var = tk.StringVar()
        self.group_combo = ttk.Combobox(left_panel, textvariable=self.group_var, state="readonly", width=25)
        self.group_combo.grid(row=2, column=1, **grid_opts)

        ttk.Label(left_panel, text="Enseignant:").grid(row=3, column=0, **grid_opts)
        self.teacher_var = tk.StringVar()
        self.teacher_combo = ttk.Combobox(left_panel, textvariable=self.teacher_var, state="readonly", width=25)
        self.teacher_combo.grid(row=3, column=1, **grid_opts)

        ttk.Label(left_panel, text="Date (YYYY-MM-DD):").grid(row=4, column=0, **grid_opts)
        self.date_entry = ttk.Entry(left_panel, width=28)
        self.date_entry.grid(row=4, column=1, **grid_opts)

        ttk.Label(left_panel, text="Heure (8-18):").grid(row=5, column=0, **grid_opts)
        self.hour_entry = ttk.Entry(left_panel, width=28)
        self.hour_entry.grid(row=5, column=1, **grid_opts)

        ttk.Label(left_panel, text="Durée (h):").grid(row=6, column=0, **grid_opts)
        self.duration_entry = ttk.Entry(left_panel, width=28)
        self.duration_entry.insert(0, "2")
        self.duration_entry.grid(row=6, column=1, **grid_opts)

        btn = tk.Button(left_panel, text="Ajouter Session", bg=ACCENT_COLOR, fg="white", font=BTN_FONT,
                        relief="flat", padx=20, pady=5, command=self.create_session)
        btn.grid(row=7, columnspan=2, pady=20)

        # Right Panel - Info
        right_panel = ttk.Frame(self.tab_create)
        right_panel.pack(side="left", fill="both", expand=True)
        
        info_lbl = ttk.Label(right_panel, text="Note: Le système assignera automatiquement une salle optimale en fonction des contraintes.",
                             background="#e1e1e1", foreground="#333", padding=15, wraplength=300)
        info_lbl.pack(fill="x", anchor="n")

    def setup_view_tab(self):
        # Toolbar
        toolbar = ttk.Frame(self.tab_view)
        toolbar.pack(fill="x", pady=(0, 10))
        ttk.Button(toolbar, text="Actualiser", command=self.refresh_list).pack(side="right")
        ttk.Button(toolbar, text="Exporter (HTML)", command=self.export_list).pack(side="right", padx=5)

        # Treeview
        columns = ("Date", "Heure", "Cours", "Type", "Groupe", "Enseignant", "Salle")
        self.tree = ttk.Treeview(self.tab_view, columns=columns, show="headings", selectmode="browse")
        
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor="center")
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(self.tab_view, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def setup_stats_tab(self):
        self.stats_text = tk.Text(self.tab_stats, height=15, width=60, font=("Consolas", 10), padx=20, pady=20, relief="flat")
        self.stats_text.pack(fill="both", expand=True)
        ttk.Button(self.tab_stats, text="Actualiser Stats", command=self.refresh_stats).pack(pady=10)

    def refresh_data(self):
        # Populate Comboboxes
        mgr = self.controller.manager
        self.course_combo['values'] = [c.code for c in mgr.courses]
        self.group_combo['values'] = [g.name for g in mgr.groups]
        self.teacher_combo['values'] = [f"{t.user_id}: {t.name}" for t in mgr.teachers]
        
        self.refresh_list()
        self.refresh_stats()

    def create_session(self):
        try:
            course = self.course_var.get()
            ctype = self.type_var.get()
            group = self.group_var.get()
            teacher_str = self.teacher_var.get()
            if not teacher_str:
                raise ValueError("Enseignant requis")
            teacher_id = int(teacher_str.split(':')[0])
            
            date = self.date_entry.get()
            hour = int(self.hour_entry.get())
            duration = int(self.duration_entry.get())

            result = self.controller.manager.create_session(course, ctype, group, teacher_id, date, hour, duration)
            if "succès" in result:
                messagebox.showinfo("Succès", result)
            else:
                messagebox.showwarning("Attention", result)
                
            self.refresh_list()
            self.refresh_stats()

        except Exception as e:
            messagebox.showerror("Erreur", str(e))

    def refresh_list(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        
        for s in self.controller.manager.sessions:
            room_str = s.room.room_id if s.room else "Non assignée"
            self.tree.insert("", "end", values=(
                s.start_time.strftime('%Y-%m-%d'),
                f"{s.start_time.hour}h - {s.end_time.hour}h",
                s.course.name,
                s.session_type.value,
                s.group.name,
                s.teacher.name,
                room_str
            ))

    def export_list(self):
        self.controller.export_sessions_to_html(self.controller.manager.sessions, "Emploi du Temps Global")

    def refresh_stats(self):
        stats = self.controller.manager.get_statistics()
        text = "RAPPORT D'ACTIVITÉ\n"
        text += "="*30 + "\n\n"
        text += f"Total Sessions : {stats['total_sessions']}\n\n"
        text += "Occupation Salles :\n"
        text += "-"*30 + "\n"
        for room, hours in stats['room_usage'].items():
            text += f"{room:<10} : {hours}h\n"
        
        self.stats_text.delete("1.0", "end")
        self.stats_text.insert("end", text)


class TeacherView(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg=BG_COLOR)
        self.controller = controller
        self.current_sessions = []

        # Header
        header = tk.Frame(self, bg=HEADER_BG, height=50)
        header.pack(fill="x")
        
        btn_back = tk.Button(header, text="⬅ Retour", bg=HEADER_BG, fg="white", font=BTN_FONT, 
                             relief="flat", command=lambda: controller.show_frame("LoginView"))
        btn_back.pack(side="left", padx=15, pady=10)
        
        tk.Label(header, text="ESPACE ENSEIGNANT", font=SUBTITLE_FONT, bg=HEADER_BG, fg="white").pack(side="left", padx=10)

        # Identification Bar
        id_bar = tk.Frame(self, bg="white", height=50, padx=20)
        id_bar.pack(fill="x", pady=(0, 20))
        
        tk.Label(id_bar, text="Identifiant :", bg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
        self.teacher_var = tk.StringVar()
        self.teacher_combo = ttk.Combobox(id_bar, textvariable=self.teacher_var, state="readonly", width=30)
        self.teacher_combo.pack(side="left", padx=10, pady=10)
        self.teacher_combo.bind("<<ComboboxSelected>>", self.load_timetable)

        # Content
        content = tk.Frame(self, bg=BG_COLOR, padx=20)
        content.pack(fill="both", expand=True)

        # Tabs
        notebook = ttk.Notebook(content)
        notebook.pack(fill="both", expand=True)

        # Tab 1: Timetable
        self.tab_timetable = ttk.Frame(notebook, padding=20)
        notebook.add(self.tab_timetable, text="   📅 Mon Planning   ")
        
        # Toolbar
        toolbar = ttk.Frame(self.tab_timetable)
        toolbar.pack(fill="x", pady=(0, 10))
        ttk.Button(toolbar, text="Exporter mon planning", command=self.export_timetable).pack(side="right")

        columns = ("Date", "Heure", "Cours", "Groupe", "Salle")
        self.tree = ttk.Treeview(self.tab_timetable, columns=columns, show="headings")
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor="center")
        self.tree.pack(fill="both", expand=True)

        # Tab 2: Reservation
        self.tab_res = ttk.Frame(notebook, padding=20)
        notebook.add(self.tab_res, text="   📝 Demande Salle   ")
        self.setup_reservation_tab()

    def refresh_data(self):
        mgr = self.controller.manager
        self.teacher_combo['values'] = [f"{t.user_id}: {t.name}" for t in mgr.teachers]
        self.room_combo['values'] = [r.room_id for r in mgr.rooms]

    def load_timetable(self, event=None):
        teacher_str = self.teacher_var.get()
        if not teacher_str:
            return
        
        tid = int(teacher_str.split(':')[0])
        self.current_sessions = self.controller.manager.get_timetable_for_teacher(tid)

        for row in self.tree.get_children():
            self.tree.delete(row)
            
        for s in self.current_sessions:
            room_str = s.room.room_id if s.room else "Non assignée"
            self.tree.insert("", "end", values=(
                s.start_time.strftime('%Y-%m-%d'),
                f"{s.start_time.hour}h - {s.end_time.hour}h",
                s.course.name,
                s.group.name,
                room_str
            ))
            
    def export_timetable(self):
        if not self.current_sessions:
            messagebox.showwarning("Export", "Veuillez d'abord charger un emploi du temps.")
            return
        self.controller.export_sessions_to_html(self.current_sessions, f"Planning Enseignant - {self.teacher_var.get()}")

    def setup_reservation_tab(self):
        panel = ttk.LabelFrame(self.tab_res, text="Formulaire de Réservation", padding=20)
        panel.pack(fill="x", anchor="n")

        grid_opts = {'padx': 5, 'pady': 10, 'sticky': 'w'}

        ttk.Label(panel, text="Salle souhaitée:").grid(row=0, column=0, **grid_opts)
        self.room_var = tk.StringVar()
        self.room_combo = ttk.Combobox(panel, textvariable=self.room_var, state="readonly", width=30)
        self.room_combo.grid(row=0, column=1, **grid_opts)

        ttk.Label(panel, text="Motif:").grid(row=1, column=0, **grid_opts)
        self.reason_entry = ttk.Entry(panel, width=50)
        self.reason_entry.grid(row=1, column=1, **grid_opts)

        btn = tk.Button(panel, text="Envoyer demande", bg=ACCENT_COLOR, fg="white", font=BTN_FONT,
                        relief="flat", padx=15, command=self.send_request)
        btn.grid(row=2, columnspan=2, pady=20)

    def send_request(self):
        teacher_str = self.teacher_var.get()
        if not teacher_str:
            messagebox.showerror("Erreur", "Veuillez vous identifier d'abord.")
            return
        
        tid = int(teacher_str.split(':')[0])
        teacher = next((t for t in self.controller.manager.teachers if t.user_id == tid), None)
        
        room = self.room_var.get()
        reason = self.reason_entry.get()
        
        msg = self.controller.manager.request_reservation(teacher, room, datetime.now(), 2, reason)
        messagebox.showinfo("Confirmation", msg)

class StudentView(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg=BG_COLOR)
        self.controller = controller
        self.current_sessions = []

        # Header
        header = tk.Frame(self, bg=HEADER_BG, height=50)
        header.pack(fill="x")
        
        btn_back = tk.Button(header, text="⬅ Retour", bg=HEADER_BG, fg="white", font=BTN_FONT, 
                             relief="flat", command=lambda: controller.show_frame("LoginView"))
        btn_back.pack(side="left", padx=15, pady=10)
        
        tk.Label(header, text="ESPACE ÉTUDIANT", font=SUBTITLE_FONT, bg=HEADER_BG, fg="white").pack(side="left", padx=10)

        # Group Selection
        id_bar = tk.Frame(self, bg="white", height=50, padx=20)
        id_bar.pack(fill="x", pady=(0, 20))

        tk.Label(id_bar, text="Mon Groupe :", bg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
        self.group_var = tk.StringVar()
        self.group_combo = ttk.Combobox(id_bar, textvariable=self.group_var, state="readonly", width=30)
        self.group_combo.pack(side="left", padx=10, pady=10)
        self.group_combo.bind("<<ComboboxSelected>>", self.load_timetable)

        # Timetable
        content = tk.Frame(self, bg=BG_COLOR, padx=20, pady=20)
        content.pack(fill="both", expand=True)

        # Header Frame
        tt_header = tk.Frame(content, bg=BG_COLOR)
        tt_header.pack(fill="x", pady=(0, 10))
        
        ttk.Label(tt_header, text="Emploi du temps de la semaine", font=("Segoe UI", 12)).pack(side="left")
        ttk.Button(tt_header, text="Exporter", command=self.export_timetable).pack(side="right")

        columns = ("Date", "Heure", "Cours", "Type", "Enseignant", "Salle")
        self.tree = ttk.Treeview(content, columns=columns, show="headings")
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor="center")
        self.tree.pack(fill="both", expand=True)

    def refresh_data(self):
        mgr = self.controller.manager
        self.group_combo['values'] = [g.name for g in mgr.groups]

    def load_timetable(self, event=None):
        grp = self.group_var.get()
        if not grp:
            return
        
        self.current_sessions = self.controller.manager.get_timetable_for_group(grp)

        for row in self.tree.get_children():
            self.tree.delete(row)
            
        for s in self.current_sessions:
            room_str = s.room.room_id if s.room else "Non assignée"
            self.tree.insert("", "end", values=(
                s.start_time.strftime('%Y-%m-%d'),
                f"{s.start_time.hour}h - {s.end_time.hour}h",
                s.course.name,
                s.session_type.value,
                s.teacher.name,
                room_str
            ))

    def export_timetable(self):
        if not self.current_sessions:
            messagebox.showwarning("Export", "Veuillez d'abord sélectionner un groupe.")
            return
        self.controller.export_sessions_to_html(self.current_sessions, f"Planning Groupe - {self.group_var.get()}")

if __name__ == "__main__":
    app = TimetableApp()
    app.mainloop()