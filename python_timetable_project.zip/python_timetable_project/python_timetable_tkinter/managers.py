from datetime import datetime, timedelta
from typing import List, Optional, Dict
from models import *

class TimetableManager:
    def __init__(self):
        self.rooms: List[Room] = []
        self.teachers: List[Teacher] = []
        self.groups: List[Group] = []
        self.courses: List[Course] = []
        self.sessions: List[Session] = []

    def add_room(self, room: Room):
        self.rooms.append(room)

    def add_teacher(self, teacher: Teacher):
        self.teachers.append(teacher)

    def add_group(self, group: Group):
        self.groups.append(group)

    def add_course(self, course: Course):
        self.courses.append(course)

    def find_available_room(self, start: datetime, end: datetime, min_capacity: int, room_type: RoomType = None) -> Optional[Room]:
        candidates = [r for r in self.rooms if r.capacity >= min_capacity]
        if room_type:
            candidates = [r for r in candidates if r.room_type == room_type]
            
        for room in candidates:
            if self.is_room_free(room, start, end):
                return room
        return None

    def is_room_free(self, room: Room, start: datetime, end: datetime) -> bool:
        for s in self.sessions:
            if s.room and s.room.room_id == room.room_id:
                if self.check_overlap(s.start_time, s.end_time, start, end):
                    return False
        return True

    def check_overlap(self, start1, end1, start2, end2):
        return max(start1, start2) < min(end1, end2)

    def create_session(self, course_code, session_type_val, group_name, teacher_id, date_str, hour, duration=2):
        # Find objects
        course = next((c for c in self.courses if c.code == course_code), None)
        group = next((g for g in self.groups if g.name == group_name), None)
        teacher = next((t for t in self.teachers if t.user_id == teacher_id), None)
        
        if not all([course, group, teacher]):
            return "Erreur: Données invalides"

        try:
            start = datetime.strptime(f"{date_str} {hour}", "%Y-%m-%d %H")
            end = start + timedelta(hours=duration)
        except ValueError:
            return "Erreur: Format date/heure invalide"

        # Check conflicts
        if not self.is_teacher_free(teacher, start, end):
            return "Erreur: Enseignant occupé"
        
        if not self.is_group_free(group, start, end):
            return "Erreur: Groupe occupé"

        # Assign room
        stype = next((t for t in SessionType if t.value == session_type_val), SessionType.LECTURE)
        rtype = RoomType.AMPHITHEATER if stype == SessionType.LECTURE else RoomType.CLASSROOM
        if stype == SessionType.PRACTICAL: rtype = RoomType.LAB
        
        room = self.find_available_room(start, end, group.size, rtype)
        if not room:
            return "Erreur: Aucune salle disponible"

        session = Session(course, stype, group, teacher, start, end, room, duration)
        self.sessions.append(session)
        return "Session créée avec succès"

    def is_teacher_free(self, teacher, start, end):
        for s in self.sessions:
            if s.teacher.user_id == teacher.user_id:
                if self.check_overlap(s.start_time, s.end_time, start, end):
                    return False
        return True

    def is_group_free(self, group, start, end):
        for s in self.sessions:
            if s.group.name == group.name:
                if self.check_overlap(s.start_time, s.end_time, start, end):
                    return False
        return True

    def get_timetable_for_teacher(self, teacher_id):
        return [s for s in self.sessions if s.teacher.user_id == teacher_id]

    def get_timetable_for_group(self, group_name):
        return [s for s in self.sessions if s.group.name == group_name]

    def get_statistics(self):
        stats = {
            'total_sessions': len(self.sessions),
            'room_usage': {r.room_id: 0 for r in self.rooms}
        }
        for s in self.sessions:
            if s.room:
                stats['room_usage'][s.room.room_id] += s.duration
        return stats

    def request_reservation(self, teacher, room_id, date, duration, reason):
        return "Demande envoyée à l'administration"
