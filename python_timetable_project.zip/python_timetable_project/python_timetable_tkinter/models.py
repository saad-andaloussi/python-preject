from enum import Enum
from dataclasses import dataclass
from typing import List, Optional
from datetime import datetime

class RoomType(Enum):
    AMPHITHEATER = "Amphithéâtre"
    CLASSROOM = "Salle de TD"
    LAB = "Laboratoire"

class SessionType(Enum):
    LECTURE = "Cours Magistral"
    TUTORIAL = "TD"
    PRACTICAL = "TP"

@dataclass
class Room:
    room_id: str
    capacity: int
    room_type: RoomType
    equipment: List[str]

@dataclass
class Teacher:
    user_id: int
    name: str
    email: str
    department: str

@dataclass
class Group:
    name: str
    size: int

@dataclass
class Course:
    code: str
    name: str

@dataclass
class Session:
    course: Course
    session_type: SessionType
    group: Group
    teacher: Teacher
    start_time: datetime
    end_time: datetime
    room: Optional[Room] = None
    duration: int = 2
